<!DOCTYPE html> 
<head>
	<link rel ="stylesheet" type ="text/css" href ="Estilos_Pie.css"/>	
	<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
</head>
<body>
	<div id="pie">
		<div id="mgp">
			<p>Este sitio ha sido creado por MGP ENTERPRISE &#174 2016 - Todos los derechos reservados</p>
		</div>
		<div id="contacto">
			<div id="imagen">
				<img src="Imagen/correoelect.png" alt="Contacto"/>
			</div>
			<div id="mail">
				<p>couchinn@couch.com</p>
			</div>
		</div>
	</div>
</body>
</html>